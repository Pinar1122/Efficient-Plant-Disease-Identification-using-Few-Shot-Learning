"""
The easyfsl library.

This library implements few-shot learning methods, along with data loading tools
for few-shot learning experiences.
"""

__version__ = "1.1.0"
