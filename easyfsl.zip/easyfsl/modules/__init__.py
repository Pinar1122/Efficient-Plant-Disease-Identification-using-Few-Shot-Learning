from .resnet import ResNet
from .predesigned_modules import *
